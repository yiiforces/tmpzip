<?php
return array(
	'gateways' => array(
		'ITS24' => 'SMSGateway\\Gateway\\ITS24',
		'Clickatell' => 'SMSGateway\\Gateway\\Clickatell',
		'Twilio' => 'SMSGateway\\Gateway\\Twilio',
		'Msg91' => 'SMSGateway\\Gateway\\Msg91',
		'Mimsms' => 'SMSGateway\\Gateway\\Mimsms',
		'Onnorokomsms' => 'SMSGateway\\Gateway\\Onnorokomsms',
	),
);