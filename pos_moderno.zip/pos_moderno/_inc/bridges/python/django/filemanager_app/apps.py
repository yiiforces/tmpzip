from __future__ import unicode_literals

from django.apps import AppConfig


class FilemanagerAppConfig(AppConfig):
    name = 'filemanager_app'
