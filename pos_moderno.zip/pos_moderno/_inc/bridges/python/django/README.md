# django_filemanager
file manager using angular &amp; django

# Installation:
django_filemanager is a django project use filemanager_app to produce a full demo of use of angular_filemanager.

# Deploy filemanager_app

in your project add filemanager_app to your Apps then add url_pattern of the app to your project; for more details see the django_filemanager project.
Finally, if you find this apps useful, please, leave a comment, if you want to contibute you are welcom ;)